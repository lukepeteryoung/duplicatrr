# =========================================================================================
# Plex Duplicate Manager (Single vs Bulk Disk Deletion with Space Tally)
# =========================================================================================

# --- Configuration ---
$PlexUrl   = "http://127.0.0.1:32400"  # Change if your server is on a different IP/port
$PlexToken = "sz5oTyHxq_gz9vdE8N6o"    # Your active Plex token

# --- Helper Functions ---
function Get-PlexData {
    param([string]$Path)
    $Separator = if ($Path.Contains("?")) { "&" } else { "?" }
    $Uri = "{0}{1}{2}X-Plex-Token={3}" -f $PlexUrl, $Path, $Separator, $PlexToken
    try {
        return Invoke-RestMethod -Uri $Uri -Method Get -Headers @{ "Accept" = "application/json" } -ErrorAction Stop
    }
    catch {
        Write-Host "[-] Error connecting to Plex API: $_" -ForegroundColor Red
        return $null
    }
}

function Remove-LocalFile {
    param([string]$FilePath)
    if (Test-Path $FilePath) {
        try {
            Write-Host ("[*] Deleting local file: {0}" -f $FilePath) -ForegroundColor Yellow
            Remove-Item -Path $FilePath -Force -ErrorAction Stop
            Write-Host "[+] Local file deleted successfully!" -ForegroundColor Green
        }
        catch {
            Write-Host ("[-] Failed to delete file from disk: {0}" -f $_.Exception.Message) -ForegroundColor Red
        }
    } else {
        Write-Host ("[!] File path not found or unreachable on disk: {0}" -f $FilePath) -ForegroundColor Yellow
    }
}

# --- Main Script Logic ---
clear
$Index = 0

if ([string]::IsNullOrEmpty($PlexToken)) {
    Write-Host "[!] Please configure your Plex Token inside the script first!" -ForegroundColor Yellow
    Exit
}

Write-Host "[*] Fetching Plex libraries..." -ForegroundColor Cyan
$SectionsContainer = Get-PlexData -Path "/library/sections"

if (-not $SectionsContainer -or -not $SectionsContainer.MediaContainer.Directory) {
    Write-Host "[-] No libraries found or unable to connect. (Check your Token or URL!)" -ForegroundColor Red
    Exit
}

$Libraries = $SectionsContainer.MediaContainer.Directory

# --- Menu Loop ---
while ($true) {
    clear
    Write-Host "=========================================" -ForegroundColor Magenta
    Write-Host "           PLEX DUPLICATE MANAGER         " -ForegroundColor Magenta
    Write-Host "=========================================" -ForegroundColor Magenta
    Write-Host ""
    
    for ($i = 0; $i -lt $Libraries.Count; $i++) {
        Write-Host ("{0}. {1} ({2})" -f ($i + 1), $Libraries[$i].title, $Libraries[$i].type) -ForegroundColor White
    }
    Write-Host ("{0}. Exit" -f ($Libraries.Count + 1)) -ForegroundColor Yellow
    Write-Host ""
    
    $Selection = Read-Host "Select a library number"
    
    if ($Selection -eq ($Libraries.Count + 1)) {
        Write-Host "[*] Exiting script. Goodbye!" -ForegroundColor Cyan
        break
    }
    
    if (-not [int]::TryParse($Selection, [ref]$Index) -or $Index -lt 1 -or $Index -gt $Libraries.Count) {
        Write-Host "[!] Invalid choice, press Enter to try again..." -ForegroundColor Yellow
        [void][Console]::ReadLine()
        continue
    }
    
    $SelectedLib = $Libraries[$Index - 1]
    
    # --- Mode Selection Menu ---
    Write-Host ""
    Write-Host "Select scanning and deletion mode:" -ForegroundColor Cyan
    Write-Host "1. Single Deletion (Go through titles one by one)" -ForegroundColor White
    Write-Host "2. Bulk Deletion   (Show all duplicates first, then mass delete)" -ForegroundColor White
    $ModeSelection = Read-Host "Enter choice (1 or 2)"
    
    if ($ModeSelection -ne "1" -and $ModeSelection -ne "2") {
        Write-Host "[!] Invalid mode selected. Press Enter to return to main menu..." -ForegroundColor Yellow
        [void][Console]::ReadLine()
        continue
    }
    
    Write-Host ("`n[*] Scanning '{0}' for duplicates..." -f $SelectedLib.title) -ForegroundColor Cyan
    
    $DuplicatePath = "/library/sections/{0}/all?all=1&duplicates=1" -f $SelectedLib.key
    $DuplicateContainer = Get-PlexData -Path $DuplicatePath
    
    if ($null -eq $DuplicateContainer) {
        Write-Host "[-] Failed to fetch library items. Press Enter to return to menu..." -ForegroundColor Red
        [void][Console]::ReadLine()
        continue
    }
    
    $MediaItems = $DuplicateContainer.MediaContainer.Metadata
    
    if (-not $MediaItems -or $MediaItems.Count -eq 0) {
        Write-Host "[+] Clear! No duplicate items found in this library." -ForegroundColor Green
        Write-Host "Press Enter to return to menu..."
        [void][Console]::ReadLine()
        continue
    }
    
    Write-Host ("`n[*] Processing metadata for {0} potential duplicate entries..." -f $MediaItems.Count) -ForegroundColor Yellow
    
    $MasterFilesList = @()
    
    foreach ($Item in $MediaItems) {
        $ItemDetailPath = "/library/metadata/{0}" -f $Item.ratingKey
        $DetailContainer = Get-PlexData -Path $ItemDetailPath
        
        $TargetItem = $Item
        if ($null -ne $DetailContainer -and $null -ne $DetailContainer.MediaContainer.Metadata) {
            $TargetItem = $DetailContainer.MediaContainer.Metadata[0]
        }
        
        if ($null -ne $TargetItem.Media) {
            foreach ($Media in $TargetItem.Media) {
                if ($null -ne $Media.Part) {
                    foreach ($Part in $Media.Part) {
                        $Width = if ($Media.width) { $Media.width } else { 0 }
                        $Bitrate = if ($Media.bitrate) { $Media.bitrate } else { 0 }
                        $Res = if ($Media.videoResolution) { $Media.videoResolution } else { "Unknown" }
                        
                        $SizeBytes = if ($Part.size) { $Part.size } else { 0 }
                        $SizeGB = [math]::Round(($SizeBytes / 1GB), 2)
                        
                        $RawFile = if ($Part.file) { $Part.file } else { "Unknown Filename" }
                        $LeafName = Split-Path $RawFile -Leaf
                        
                        $MasterFilesList += [PSCustomObject]@{
                            PartId     = $Part.id
                            RatingKey  = $TargetItem.ratingKey
                            Title      = $TargetItem.title
                            Year       = $TargetItem.year
                            File       = $RawFile
                            Width      = $Width
                            Bitrate    = $Bitrate
                            SizeBytes  = $SizeBytes # Store raw bytes for exact summing later
                            Display    = ("{0}p | {1} GB | {2} kbps | {3}" -f $Res, $SizeGB, [math]::Round($Bitrate/1000), $LeafName)
                        }
                    }
                }
            }
        }
    }
    
    $GroupedDuplicates = $MasterFilesList | Group-Object -Property Title, Year | Where-Object { $_.Count -gt 1 }
    
    if ($GroupedDuplicates.Count -eq 0) {
        Write-Host "[+] All remaining items are distinct titles. No multi-file duplicates found." -ForegroundColor Green
        Write-Host "Press Enter to return to menu..."
        [void][Console]::ReadLine()
        continue
    }
    
    Write-Host ("`n[!] Found {0} unique titles with genuine duplicate versions.`n" -f $GroupedDuplicates.Count) -ForegroundColor Yellow
    
    # -------------------------------------------------------------------------------------
    # MODE 1: SINGLE DELETION (Interactive One-by-One)
    # -------------------------------------------------------------------------------------
    if ($ModeSelection -eq "1") {
        foreach ($Group in $GroupedDuplicates) {
            $SortedFiles = $Group.Group | Sort-Object Width, Bitrate -Descending
            $KeepFile = $SortedFiles[0]
            $LowerQualityDuplicates = $SortedFiles | Select-Object -Skip 1
            
            Write-Host "--------------------------------------------------" -ForegroundColor Gray
            Write-Host ("Title: {0} ({1})" -f $KeepFile.Title, $KeepFile.Year) -ForegroundColor Cyan
            
            Write-Host "  [KEEPING]   -> " -NoNewline -ForegroundColor Green
            Write-Host $KeepFile.Display
            Write-Host ("               Path: {0}" -f $KeepFile.File) -ForegroundColor Gray
            Write-Host ""
            
            foreach ($Dup in $LowerQualityDuplicates) {
                Write-Host "  [DELETING]  -> " -NoNewline -ForegroundColor Red
                Write-Host $Dup.Display
                Write-Host ("               Path: {0}" -f $Dup.File) -ForegroundColor Gray
            }
            Write-Host ""
            
            $Action = Read-Host "Do you want to delete the lower quality duplicate(s) for this title? (Y/N)"
            if ($Action -imatch "y") {
                $Confirm = Read-Host "Confirm PERMANENT deletion from local disk drive? (Y/N)"
                if ($Confirm -imatch "y") {
                    foreach ($Dup in $LowerQualityDuplicates) {
                        Remove-LocalFile -FilePath $Dup.File
                    }
                }
            }
        }
    }
    
    # -------------------------------------------------------------------------------------
    # MODE 2: BULK DELETION (Show All First, Tally Space, Then Mass Delete)
    # -------------------------------------------------------------------------------------
    elseif ($ModeSelection -eq "2") {
        $AllBulkDeletions = @()
        $TotalBytesToClear = 0
        
        # Phase 2.1: Print everything and capture sizes
        foreach ($Group in $GroupedDuplicates) {
            $SortedFiles = $Group.Group | Sort-Object Width, Bitrate -Descending
            $KeepFile = $SortedFiles[0]
            $LowerQualityDuplicates = $SortedFiles | Select-Object -Skip 1
            
            $AllBulkDeletions += $LowerQualityDuplicates
            
            # Loop to tally total byte data
            foreach ($Dup in $LowerQualityDuplicates) {
                $TotalBytesToClear += $Dup.SizeBytes
            }
            
            Write-Host "--------------------------------------------------" -ForegroundColor Gray
            Write-Host ("Title: {0} ({1})" -f $KeepFile.Title, $KeepFile.Year) -ForegroundColor Cyan
            
            Write-Host "  [KEEPING]   -> " -NoNewline -ForegroundColor Green
            Write-Host $KeepFile.Display
            Write-Host ("               Path: {0}" -f $KeepFile.File) -ForegroundColor Gray
            Write-Host ""
            
            foreach ($Dup in $LowerQualityDuplicates) {
                Write-Host "  [DELETING]  -> " -NoNewline -ForegroundColor Red
                Write-Host $Dup.Display
                Write-Host ("               Path: {0}" -f $Dup.File) -ForegroundColor Gray
            }
            Write-Host ""
        }
        
        # Calculate Total Storage Space to Recover
        $TotalGBToClear = [math]::Round(($TotalBytesToClear / 1GB), 2)
        
        # Display the custom Tally Box
        Write-Host "==================================================" -ForegroundColor Magenta
        Write-Host "                SUMMARY TOTALS                    " -ForegroundColor Magenta
        Write-Host "==================================================" -ForegroundColor Magenta
        Write-Host ("  Files Slated for Removal : {0}" -f $AllBulkDeletions.Count) -ForegroundColor Yellow
        Write-Host ("  Total Storage to Recover : {0} GB" -f $TotalGBToClear) -ForegroundColor Green
        Write-Host "==================================================" -ForegroundColor Magenta
        Write-Host ""
        
        # Phase 2.2: Mass Prompt Execution
        $Action = Read-Host "Do you want to MASS DELETE all lower quality duplicates listed above? (Y/N)"
        if ($Action -imatch "y") {
            $Confirm = Read-Host "CRITICAL CONFIRMATION: Permanently delete all targeted files from disk? (Y/N)"
            if ($Confirm -imatch "y") {
                Write-Host "`n[*] Commencing bulk processing execution..." -ForegroundColor Cyan
                foreach ($Dup in $AllBulkDeletions) {
                    Remove-LocalFile -FilePath $Dup.File
                }
            } else {
                Write-Host "[*] Bulk deletion aborted by user." -ForegroundColor Yellow
            }
        } else {
            Write-Host "[*] Bulk deletion aborted by user." -ForegroundColor Yellow
        }
    }
    
    Write-Host "`n[*] Review finished. Press Enter to return to the main menu..."
    [void][Console]::ReadLine()
}